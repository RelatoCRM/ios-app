//
//  FeaturedLeads.swift
//  Relato
//
//  Created by Diego Herrera Redondo on 24/10/24.
//

import SwiftUI

struct FeaturedLeads: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    FeaturedLeads()
}
