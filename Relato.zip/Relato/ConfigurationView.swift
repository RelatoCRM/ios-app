//
//  ConfigurationView.swift
//  Relato
//
//  Created by Diego Herrera Redondo on 23/10/24.
//

import SwiftUI

struct ConfigurationView: View {
    var body: some View {
        VStack {
            
        }.background(Color("BackgroundColor"))
    }
}

#Preview {
    ConfigurationView()
}
